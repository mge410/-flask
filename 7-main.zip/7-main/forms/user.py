from flask_wtf import FlaskForm
from wtforms import PasswordField, StringField, TextAreaField, SubmitField, EmailField
from wtforms.validators import DataRequired


class RegisterForm(FlaskForm):
    email = EmailField('Почта', validators=[DataRequired()])
    password = PasswordField('Пароль', validators=[DataRequired()])
    password_again = PasswordField('Повторите пароль', validators=[DataRequired()])
    surname = StringField('Ваша фамилия', validators=[DataRequired()])
    name = StringField('Ваше имя', validators=[DataRequired()])
    age = StringField("Ваш возраст", validators=[DataRequired()])
    position = StringField("Вашa должность", validators=[DataRequired()])
    speciality = StringField("Ваша специальность", validators=[DataRequired()])
    address = StringField("Ваш адресss", validators=[DataRequired()])
    submit = SubmitField('Войти')